const Alexa = require('ask-sdk-core');
const i18n = require('i18next');
const sprintf = require('i18next-sprintf-postprocessor');
const persistence = require('./persistence');

let DOCUMENT_ID = "";
const info = require('./informacionrvce');

let DataSource = {
    "mensaje": {
        "encabezado": "",
        "by": "",
        "titulo": "",
        "msj": "",
        "footer": ""
    }
};

let infoSources = DataSource.mensaje;
let name = '';
let glucosa = 0;

const createDirectivePayload = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};
const RecommendationTable = {
    "diabetes": [
        "La diabetes es una enfermedad crónica que se caracteriza por niveles elevados de azúcar (glucosa) en la sangre. Esto puede ocurrir debido a una producción insuficiente de insulina por parte del páncreas o porque el cuerpo no responde adecuadamente a la insulina producida. ",
        "Síntomas comunes de la diabetes incluyen sed excesiva, aumento del apetito, micción frecuente, fatiga, visión borrosa y cicatrización lenta de heridas. El manejo adecuado de la diabetes implica cambios en el estilo de vida, medicamentos y, en algunos casos, la administración de insulina.",
        "Es importante destacar que la diabetes puede tener complicaciones graves si no se trata adecuadamente. Estas complicaciones pueden incluir enfermedades cardiovasculares, problemas renales, neuropatías, problemas oculares, entre otros. Es importante que consultes a un profesional de la salud para una evaluación adecuada y un plan de tratamiento personalizado.",
        "El diagnóstico y tratamiento de la diabetes deben ser realizados por profesionales de la salud. Los pacientes con diabetes deben aprender a controlar sus niveles de glucosa en sangre a través de pruebas regulares y seguir un plan de tratamiento que incluya cambios en el estilo de vida, medicamentos y, en algunos casos, la administración de insulina.",
        ],
    "epilepsia":[
        "La epilepsia es una afección neurológica crónica que afecta el sistema nervioso central y se caracteriza por la aparición recurrente de convulsiones. Las convulsiones son episodios de actividad cerebral anormal que pueden causar sacudidas involuntarias, pérdida de conciencia o cambios en la percepción.",
        "Causas de la epilepsia pueden incluir lesiones cerebrales, trastornos genéticos, infecciones, accidentes cerebrovasculares o tumores cerebrales, aunque en algunos casos la causa puede ser desconocida. Existen diferentes tipos de convulsiones y la epilepsia puede manifestarse de diversas maneras en cada persona.",
        "El diagnóstico de la epilepsia generalmente se basa en la historia clínica del paciente, los síntomas, los informes de testigos de las convulsiones y los resultados de pruebas como el electroencefalograma (EEG) y estudios de imágenes cerebrales.",
        ],
    "alzheimer":[
        "El Alzheimer es una enfermedad neurodegenerativa progresiva y la forma más común de demencia. Afecta la memoria, el pensamiento y el comportamiento de manera gradual y se produce debido a la acumulación anormal de proteínas en el cerebro, como placas de beta-amiloide y ovillos de tau.",
        "Los síntomas iniciales del Alzheimer pueden incluir dificultades para recordar información reciente, desorientación en tiempo y espacio, problemas con el lenguaje y cambios en el estado de ánimo y la personalidad. A medida que la enfermedad avanza, las personas pueden experimentar dificultades para realizar tareas diarias y comunicarse.",
        "Lamentablemente, el Alzheimer no tiene cura, pero existen tratamientos que pueden ayudar a aliviar los síntomas y mejorar la calidad de vida de los pacientes. Es importante consultar a profesionales de la salud para obtener una evaluación y diagnóstico adecuados, así como para recibir información actualizada sobre esta enfermedad y sus tratamientos.",
        ],
}

const RecommendationEnglish = {
      "diabetes": [
          "Diabetes is a chronic disease characterized by elevated blood sugar (glucose) levels. This can occur due to insufficient insulin production by the pancreas or because the body does not respond properly to the insulin produced. ",
          "Common symptoms of diabetes include excessive thirst, increased appetite, frequent urination, fatigue, blurred vision, and slow wound healing. Proper management of diabetes involves lifestyle changes, medications, and in some cases, insulin administration.",
          "It is important to note that diabetes can have serious complications if not treated properly. These complications can include cardiovascular disease, kidney problems, neuropathy, eye problems, among others. It is important that you consult a health professional for a proper evaluation and a personalized treatment plan.",
          "The diagnosis and treatment of diabetes must be carried out by health professionals. Patients with diabetes must learn to control their blood glucose levels through regular testing and follow a treatment plan that includes lifestyle changes, medications and, in some cases, the administration of insulin.",
          ],
      "epilepsy":[
        "Epilepsy is a chronic neurological condition that affects the central nervous system and is characterized by recurrent onset of seizures. Seizures are episodes of abnormal brain activity that can cause involuntary jerks, loss of consciousness, or changes in perception.",
        "Causes of epilepsy can include brain damage, genetic disorders, infections, stroke, or brain tumors, although in some cases the cause may be unknown. There are different types of seizures, and epilepsy can manifest in different ways in each person.",
        "The diagnosis of epilepsy is generally based on the patient's medical history, symptoms, witness reports of seizures, and results of tests such as electroencephalogram (EEG) and brain imaging studies.",
          ],
      "alzheimer":[
        "Alzheimer's is a progressive neurodegenerative disease and the most common form of dementia. It gradually affects memory, thinking and behavior and is caused by the abnormal buildup of proteins in the brain, such as beta-amyloid plaques and tau tangles.",
        "Initial symptoms of Alzheimer's can include difficulty remembering recent information, disorientation in time and space, problems with language, and changes in mood and personality. As the disease progresses, people may experience difficulty performing daily tasks and communicating.",
        "Unfortunately, there is no cure for Alzheimer's, but there are treatments that can help alleviate symptoms and improve the quality of life of patients. It is important to consult health professionals for proper evaluation and diagnosis, as well as to receive updated information about this disease and its treatments.",
          ],
}

const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
  },
  handle(handlerInput) {
    const { attributesManager } = handlerInput;
    const requestAttributes = attributesManager.getRequestAttributes();
    const sessionAttributes = attributesManager.getSessionAttributes();

    const name = sessionAttributes['nombre'];
    const nombre = name.charAt(0).toUpperCase() + name.slice(1);
    const glucosa = sessionAttributes['glucosa'];

    const encabezado = requestAttributes.t('TITLE');
    const by = requestAttributes.t('BY');
    const titulo = requestAttributes.t('T_WELCOME');
    let speakOutput = requestAttributes.t('WELCOME_MESSAGE');
    const footer = requestAttributes.t('FOOTER');

    if ((name !== undefined && name !== null) || (glucosa !== undefined && glucosa !== null && glucosa !== 0)) {
      speakOutput = requestAttributes.t('WELCOME_DATA', nombre, glucosa);
    } else if (name === undefined && glucosa === undefined) {
      speakOutput = requestAttributes.t('WELCOME_MESSAGE');
    } else if (name === undefined) {
      speakOutput = requestAttributes.t('WELCOME_NO_NAME', glucosa);
    } else if (glucosa === undefined) {
      speakOutput = requestAttributes.t('WELCOME_NO_GLUCOSA', nombre);
    }

    infoSources.encabezado = encabezado;
    infoSources.by = by;
    infoSources.titulo = titulo;
    infoSources.msj = speakOutput;
    infoSources.footer = footer;
    
   
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
      DOCUMENT_ID = "Bienvenida";
      const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
      handlerInput.responseBuilder.addDirective(aplDirective);
    }

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .reprompt(speakOutput)
      .getResponse();
  }
};


const GlucosaIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'GlucosaIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        const slots = handlerInput.requestEnvelope.request.intent.slots;

        let name = slots.name.value;
        const glucosa = slots.glucosa.value;
        let nombre = name.charAt(0).toUpperCase() + name.slice(1);

        if(name === '' || name === null || name === undefined){
            name = sessionAttributes['nombre'];
        }else{
            sessionAttributes['nombre'] = name;
        }
        
        sessionAttributes['glucosa'] = glucosa;
        
        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_REG');
        let speechText //= requestAttributes.t('LOAD_DATA', nombre, glucosa);
        
        if(glucosa>=1 && glucosa<=69){
            speechText = requestAttributes.t('GLUCOSA_BAJA', nombre, glucosa);
             const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_BAJA');
                let speakOutput = requestAttributes.t('GLUCOSA_BAJA', nombre, glucosa);
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                 
                DOCUMENT_ID = "GlucosaBaja";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
        }else if(glucosa>=70 && glucosa<=139){
            speechText = requestAttributes.t('GLUCOSA_NORMAL', nombre, glucosa);
            const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_NORMAL');
                let speakOutput = requestAttributes.t('GLUCOSA_NORMAL', nombre, glucosa);
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                 
                DOCUMENT_ID = "GlucosaNormal";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
        }else if(glucosa>=140 && glucosa<=199){
            speechText = requestAttributes.t('GLUCOSA_PREDIABETES', nombre, glucosa);
            const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_PREDIABETES');
                let speakOutput = requestAttributes.t('GLUCOSA_PREDIABETES', nombre, glucosa);
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                 
                DOCUMENT_ID = "GlucosaPrediabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
        }else if(glucosa>=200){
            speechText = requestAttributes.t('GLUCOSA_DIABETES', nombre, glucosa);
            const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_DIABETES');
                let speakOutput = requestAttributes.t('GLUCOSA_DIABETES', nombre, glucosa);
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                 
                DOCUMENT_ID = "GlucosaDiabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
        }

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withShouldEndSession(false)
            .getResponse();
    }
};


const InformacionEnfermedadesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'InformacionEnfermedadesIntent';
    },
    handle(handlerInput) {
        const { enfermedad } = handlerInput.requestEnvelope.request.intent.slots;
        const { attributesManager } = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        let speakOutput = "";
        let speechText;
        
        if (enfermedad && RecommendationTable[enfermedad.value]) {
            let recommendations = RecommendationTable[enfermedad.value];
            let randomIndex = Math.floor(Math.random() * recommendations.length);
            let recommendation = recommendations[randomIndex];
            speakOutput = requestAttributes.t('ENFERMEDAD', enfermedad.value, recommendation);
            speechText = requestAttributes.t('ENFERMEDAD', enfermedad.value, recommendation);
        
            if (recommendation === "La diabetes es una enfermedad crónica que se caracteriza por niveles elevados de azúcar (glucosa) en la sangre. Esto puede ocurrir debido a una producción insuficiente de insulina por parte del páncreas o porque el cuerpo no responde adecuadamente a la insulina producida."){
                
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Síntomas comunes de la diabetes incluyen sed excesiva, aumento del apetito, micción frecuente, fatiga, visión borrosa y cicatrización lenta de heridas. El manejo adecuado de la diabetes implica cambios en el estilo de vida, medicamentos y, en algunos casos, la administración de insulina."){
               
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if (recommendation ==="Es importante destacar que la diabetes puede tener complicaciones graves si no se trata adecuadamente. Estas complicaciones pueden incluir enfermedades cardiovasculares, problemas renales, neuropatías, problemas oculares, entre otros. Es importante que consultes a un profesional de la salud para una evaluación adecuada y un plan de tratamiento personalizado."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if (recommendation ==="El diagnóstico y tratamiento de la diabetes deben ser realizados por profesionales de la salud. Los pacientes con diabetes deben aprender a controlar sus niveles de glucosa en sangre a través de pruebas regulares y seguir un plan de tratamiento que incluya cambios en el estilo de vida, medicamentos y, en algunos casos, la administración de insulina."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID,DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "La epilepsia es una afección neurológica crónica que afecta el sistema nervioso central y se caracteriza por la aparición recurrente de convulsiones. Las convulsiones son episodios de actividad cerebral anormal que pueden causar sacudidas involuntarias, pérdida de conciencia o cambios en la percepción."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('EPILEPSIA_1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Epilepsia";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Causas de la epilepsia pueden incluir lesiones cerebrales, trastornos genéticos, infecciones, accidentes cerebrovasculares o tumores cerebrales, aunque en algunos casos la causa puede ser desconocida. Existen diferentes tipos de convulsiones y la epilepsia puede manifestarse de diversas maneras en cada persona."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('EPILEPSIA_2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Epilepsia";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "El diagnóstico de la epilepsia generalmente se basa en la historia clínica del paciente, los síntomas, los informes de testigos de las convulsiones y los resultados de pruebas como el electroencefalograma (EEG) y estudios de imágenes cerebrales."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('EPILEPSIA_3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Epilepsia";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "El Alzheimer es una enfermedad neurodegenerativa progresiva y la forma más común de demencia. Afecta la memoria, el pensamiento y el comportamiento de manera gradual y se produce debido a la acumulación anormal de proteínas en el cerebro, como placas de beta-amiloide y ovillos de tau."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('ALZHEIMER1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Bienvenida";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Los síntomas iniciales del Alzheimer pueden incluir dificultades para recordar información reciente, desorientación en tiempo y espacio, problemas con el lenguaje y cambios en el estado de ánimo y la personalidad. A medida que la enfermedad avanza, las personas pueden experimentar dificultades para realizar tareas diarias y comunicarse."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('ALZHEIMER2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Bienvenida";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Lamentablemente, el Alzheimer no tiene cura, pero existen tratamientos que pueden ayudar a aliviar los síntomas y mejorar la calidad de vida de los pacientes. Es importante consultar a profesionales de la salud para obtener una evaluación y diagnóstico adecuados, así como para recibir información actualizada sobre esta enfermedad y sus tratamientos."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('ALZHEIMER3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Bienvenida";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }

        } else {
            speechText = requestAttributes.t('RECOMENDATION_NOFOUND');
            
            const encabezado = requestAttributes.t('TITLE');
            const by = requestAttributes.t('BY');
            const titulo = requestAttributes.t('T_RECOMENDATION_NOFOUND');
            let speakOutput = requestAttributes.t('RECOMENDATION_NOFOUND');
            const footer = requestAttributes.t('FOOTER');
            
            infoSources.encabezado = encabezado;
            infoSources.by = by;
            infoSources.titulo = titulo;
            infoSources.msj = speakOutput;
            infoSources.footer = footer;
            
            DOCUMENT_ID = "Bienvenida";
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
            }
        }
    
        const repromptOutput = requestAttributes.t('OTHER_RECOMENDATION');
        
        return handlerInput.responseBuilder
            .speak(speechText + repromptOutput ) ////speechText
            .reprompt(speechText + repromptOutput)
            .withShouldEndSession(false)
            .getResponse();
    }
    
};




//***************************************************************************************************

const InformationEnfermedadesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'InformationEnfermedadesIntent';
    },
    handle(handlerInput) {
        const { enfermedad } = handlerInput.requestEnvelope.request.intent.slots;
        const { attributesManager } = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        let speakOutput = "";
        let speechText;
        
        if (enfermedad && RecommendationEnglish[enfermedad.value]) {
            let recommendations = RecommendationEnglish[enfermedad.value];
            let randomIndex = Math.floor(Math.random() * recommendations.length);
            let recommendation = recommendations[randomIndex];
            speakOutput = requestAttributes.t('ENFERMEDAD', enfermedad.value, recommendation);
            speechText = requestAttributes.t('ENFERMEDAD', enfermedad.value, recommendation);
        
            if (recommendation === "Diabetes is a chronic disease characterized by elevated blood sugar (glucose) levels. This can occur due to insufficient insulin production by the pancreas or because the body does not respond properly to the insulin produced. "){
                
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Common symptoms of diabetes include excessive thirst, increased appetite, frequent urination, fatigue, blurred vision, and slow wound healing. Proper management of diabetes involves lifestyle changes, medications, and in some cases, insulin administration."){
               
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if (recommendation ==="It is important to note that diabetes can have serious complications if not treated properly. These complications can include cardiovascular disease, kidney problems, neuropathy, eye problems, among others. It is important that you consult a health professional for a proper evaluation and a personalized treatment plan."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if (recommendation ==="The diagnosis and treatment of diabetes must be carried out by health professionals. Patients with diabetes must learn to control their blood glucose levels through regular testing and follow a treatment plan that includes lifestyle changes, medications and, in some cases, the administration of insulin."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T2_DIABETES');
                let speakOutput = requestAttributes.t('DIABETES4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Diabetes";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID,DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Epilepsy is a chronic neurological condition that affects the central nervous system and is characterized by recurrent onset of seizures. Seizures are episodes of abnormal brain activity that can cause involuntary jerks, loss of consciousness, or changes in perception."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('EPILEPSIA_1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Epilepsia";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Causes of epilepsy can include brain damage, genetic disorders, infections, stroke, or brain tumors, although in some cases the cause may be unknown. There are different types of seizures, and epilepsy can manifest in different ways in each person."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('EPILEPSIA_2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Epilepsia";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "The diagnosis of epilepsy is generally based on the patient's medical history, symptoms, witness reports of seizures, and results of tests such as electroencephalogram (EEG) and brain imaging studies."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('EPILEPSIA_3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Epilepsia";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Alzheimer's is a progressive neurodegenerative disease and the most common form of dementia. It gradually affects memory, thinking and behavior and is caused by the abnormal buildup of proteins in the brain, such as beta-amyloid plaques and tau tangles."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('ALZHEIMER1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Alzheimer";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Initial symptoms of Alzheimer's can include difficulty remembering recent information, disorientation in time and space, problems with language, and changes in mood and personality. As the disease progresses, people may experience difficulty performing daily tasks and communicating."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('ALZHEIMER2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Alzheimer";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(recommendation === "Unfortunately, there is no cure for Alzheimer's, but there are treatments that can help alleviate symptoms and improve the quality of life of patients. It is important to consult health professionals for proper evaluation and diagnosis, as well as to receive updated information about this disease and its treatments."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('T_EPILEPSIA');
                let speakOutput = requestAttributes.t('ALZHEIMER3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "Alzheimer";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }

        } else {
            speechText = requestAttributes.t('RECOMENDATION_NOFOUND:');
            
            const encabezado = requestAttributes.t('TITLE');
            const by = requestAttributes.t('BY');
            const titulo = requestAttributes.t('T_RECOMENDATION_NOFOUND');
            let speakOutput = requestAttributes.t('RECOMENDATION_NOFOUND');
            const footer = requestAttributes.t('FOOTER');
            
            infoSources.encabezado = encabezado;
            infoSources.by = by;
            infoSources.titulo = titulo;
            infoSources.msj = speakOutput;
            infoSources.footer = footer;
            
            DOCUMENT_ID = "Bienvenida";
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
            }
        }
    
        const repromptOutput = requestAttributes.t('OTHER_RECOMENDATION');
        
        return handlerInput.responseBuilder
            .speak(speechText + repromptOutput ) ////speechText
            .reprompt(speechText + repromptOutput)
            .withShouldEndSession(false)
            .getResponse();
    }
    
};








const MarcoLegalIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MarcoLegalIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();

        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('MSG_T_MARCO');
        const speakOutput = requestAttributes.t('MSG_MARCO');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
      //  if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        //    DOCUMENT_ID = "MarcoLegal";
         //   const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
           // handlerInput.responseBuilder.addDirective(aplDirective);
        //}


        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .withShouldEndSession(false)
            .getResponse();
    }
};



const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        
        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_HELP');
        const speakOutput = requestAttributes.t('HELP');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            DOCUMENT_ID = "Ayuda";
            const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
            handlerInput.responseBuilder.addDirective(aplDirective);
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .withShouldEndSession(false)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();

        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_CANCEL');
        const speakOutput = requestAttributes.t('CANCEL');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            DOCUMENT_ID = "Despedida";
            const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .withShouldEndSession(true)
            .getResponse();
    }
};

const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();

        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_FALLBACK');
        const speakOutput = requestAttributes.t('FALLBACK');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            DOCUMENT_ID = "Error";
            const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        return handlerInput.responseBuilder.getResponse();
    }
};

const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_ERROR');
        const speakOutput = requestAttributes.t('ERROR');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            DOCUMENT_ID = "Error";
            const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
            handlerInput.responseBuilder.addDirective(aplDirective);
        }


        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


// FUNCIONES PARA TRADUCIR
const LoggingRequestInterceptor = {
    process(handlerInput) {
        console.log(`Incoming request: ${JSON.stringify(handlerInput.requestEnvelope.request)}`);
    }
};

const LoggingResponseInterceptor = {
    process(handlerInput, response) {
      console.log(`Outgoing response: ${JSON.stringify(response)}`);
    }
};

const LocalizationRequestInterceptor = {
  process(handlerInput) {
    const localizationClient = i18n.use(sprintf).init({
      lng: handlerInput.requestEnvelope.request.locale,
      overloadTranslationOptionHandler: sprintf.overloadTranslationOptionHandler,
      resources: info,
      returnObjects: true
    });
    const attributes = handlerInput.attributesManager.getRequestAttributes();
    attributes.t = function (...args) {
      return localizationClient.t(...args);
    }
  }
};

//FUNCIONES PARA VERIFICAR Y GUARDAR DATOS DE LA SESIÓN
const LoadAttributesRequestInterceptor = {
    async process(handlerInput) {
        if(handlerInput.requestEnvelope.session['new']){
            const {attributesManager} = handlerInput;
            const persistentAttributes = await attributesManager.getPersistentAttributes() || {};
            handlerInput.attributesManager.setSessionAttributes(persistentAttributes);
        }
    }
};

const SaveAttributesResponseInterceptor = {
    async process(handlerInput, response) {
        const {attributesManager} = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const shouldEndSession = (typeof response.shouldEndSession === "undefined" ? true : response.shouldEndSession);
        if(shouldEndSession || handlerInput.requestEnvelope.request.type === 'SessionEndedRequest') {       
            attributesManager.setPersistentAttributes(sessionAttributes);
            await attributesManager.savePersistentAttributes();
        }
    }
};


exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        GlucosaIntentHandler,
        InformacionEnfermedadesIntentHandler,
        InformationEnfermedadesIntentHandler,
        MarcoLegalIntentHandler,
        
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .addRequestInterceptors(
        LocalizationRequestInterceptor,
        LoggingRequestInterceptor,
        LoadAttributesRequestInterceptor)
    .addResponseInterceptors(
        LoggingResponseInterceptor,
        SaveAttributesResponseInterceptor)
    .withPersistenceAdapter(persistence.getPersistenceAdapter())
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();
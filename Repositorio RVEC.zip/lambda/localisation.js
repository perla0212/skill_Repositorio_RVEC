module.exports = {
    es: {
        translation: {
            WELCOME_MSG: '¡Bienvenido al repositorio RVEC!te podemosmos dar informacion sobre las enfermedades de la diabetes, epilesia, alzheimer al igual puedes crear recordatorios de medicame y tambien puedes ir registrando tu glucosa',
            HELP_MSG: 'Bienvenido te podemosmos dar informacion sobre las enfermedades de la diabetes, epilesia, alzheimer al igual puedes crear recordatorios de medicame y tambien puedes ir registrando tu glucosa dar informacion sobre las enfermedades de la diabetes, epilesia, alzheimer al igual puedes crear recordatorios de medicame y tambien puedes ir registrando tu glucosa.',
            GOODBYE_MSG: 'Hasta luego! ',
            REFLECTOR_MSG: 'Acabas de activar %s ',
            FALLBACK_MSG: 'Lo siento, no se nada sobre eso. Por favor inténtalo otra vez. ',
            ERROR_MSG: 'Lo siento, ha habido un problema. Por favor inténtalo otra vez. '
        }
    }
}